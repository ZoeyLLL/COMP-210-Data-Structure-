package assn04;

import java.util.LinkedList;
import java.util.Queue;
public class NonEmptyBST<T extends Comparable<T>> implements BST<T> {
	private T _element;
	private BST<T> _left;
	private BST<T> _right;

	public NonEmptyBST(T element) {

		_left = new EmptyBST<T>();
		_right = new EmptyBST<T>();
		_element = element;
	}

	// TODO: insert
	@Override
	public BST<T> insert(T element) {
		if (_element.compareTo(element) < 0) {
			if (_right.isEmpty())
				_right = new NonEmptyBST<T>(element);
				_right.insert(element);
		} else if (_element.compareTo(element) > 0) {
			if (_left.isEmpty())
				_left = new NonEmptyBST<T>(element);
				_left.insert(element);
		}
		return this;
	}

	@Override
	public T getSuccessor() {
		if (getRight().isEmpty())
			throw new UnsupportedOperationException();
		BST<T> child = _right;
		while (!child.getLeft().isEmpty())
			child = child.getLeft();
		return child.getElement();
	}
	@Override
	public BST<T> search(T element) {
		if (this.getElement().equals(element)) {
			return this;
		} else {
			if (this.getElement().compareTo(element) < 0) {
				if (this.getRight().isEmpty()) {
					return (null);
				} else {
					return this._right.search(element);
				}
			} else {
				if (this.getLeft().isEmpty()) {
					return (null);
				} else {
					return this._left.search(element);
				}
			}
		}
	}


	@Override
	public BST<T> findMin() {
		if (this.getLeft().isEmpty()) {
			return this;
		} else {
			return this._left.findMin();
		}
	}


	// TODO: remove
	@Override
	public BST<T> remove(T element) {
		if (_element.compareTo(element) < 0) {
			if (_right.isEmpty())
				return this;
			_right = _right.remove(element);
		} else if (_element.compareTo(element) > 0) {
			if (_left.isEmpty())
				return this;
			_left = _left.remove(element);
		} else {
			if (_left.isEmpty())
				return _right;
			if (_right.isEmpty())
				return _left;
			_element = getSuccessor();
			_right = _right.remove(_element);
		}
		return this;
	}

	// TODO: printPreOrderTraversal
	@Override
	public void printPreOrderTraversal() {
		if (this.isEmpty()) {
			return;
		}
		System.out.print(_element + " ");
		_left.printPreOrderTraversal();
		_right.printPreOrderTraversal();
	}


	// TODO: printPostOrderTraversal
	@Override
	public void printPostOrderTraversal() {
		if (this.isEmpty()) {
			return;
		}
		_left.printPostOrderTraversal();
		_right.printPostOrderTraversal();
		System.out.print(_element + " ");
	}

	// TODO: printBreadthFirstTraversal
	@Override
	public void printBreadthFirstTraversal() {
		Queue<BST<T>> bstQueue = new LinkedList<>();
		bstQueue.offer(this);
		while (!bstQueue.isEmpty()) {
			BST<T> now = bstQueue.poll();
			System.out.print(now.getElement() + " ");
			if (!now.getLeft().isEmpty())
				bstQueue.offer(now.getLeft());
			if (!now.getRight().isEmpty())
				bstQueue.offer(now.getRight());

		}
	}



	@Override
	public int getHeight() {
		return Math.max(_left.getHeight(), _right.getHeight())+1;
	}


	@Override
	public BST<T> getLeft() {
		return _left;
	}

	@Override
	public BST<T> getRight() {
		return _right;
	}

	@Override
	public T getElement() {
		return _element;
	}

	@Override
	public boolean isEmpty() {
		return false;
	}

}
